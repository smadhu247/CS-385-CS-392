/*******************************************************************************
 * Name         : sum.h
 * Author       : Sanjana Madhu and Lasya Josyula
 * Date         : 05/07/2021
 * Description  : Lab 12
 * Pledge : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#ifndef SUM_H_
#define SUM_H_

/* Function prototype */
int sum_array(int *array, const int length);

#endif
